-- { Services } --

local SelectionService: Selection = game:GetService("Selection");
local RunService: RunService = game:GetService("RunService");

if (not plugin) then
  return;
end

-- { Packages } --

local Packages = script.Packages;

---@module Packages.React
local React = require(Packages.React);
---@module Packages.ReactRoblox
local ReactRoblox = require(Packages.ReactRoblox);
local Properties = require(Packages.Properties);

-- { Components } --

local Components = script.Components;

local ContainerComponent = require(Components["Container.story"]);

-- { Plugin } --

local GetProperties = Properties.new("FullAPIDump");

local Toolbar = plugin:CreateToolbar("Reactify");
local PluginButton = Toolbar:CreateButton("Reactify UI", "Opens the UI", "rbxassetid://113625051647217");
PluginButton.ClickableWhenViewportHidden = true;

local PluginGuiInfo = DockWidgetPluginGuiInfo.new(
  Enum.InitialDockState.Float,
  false,
  false,
  400, 700,
  400, 700
);

local CurrentWidget = plugin:CreateDockWidgetPluginGui("Reactify UI", PluginGuiInfo);
CurrentWidget.Title = "Reactify UI";
CurrentWidget.Name = "Reactify UI";

Root = ReactRoblox.createRoot(CurrentWidget);
Root:render(React.createElement(ContainerComponent.story, {GetProperties = GetProperties}));

PluginButton.Click:Connect(function()
  PluginButton:SetActive(not CurrentWidget.Enabled);
  CurrentWidget.Enabled = not CurrentWidget.Enabled;
end)

CurrentWidget:BindToClose(function()
  CurrentWidget.Enabled = false;
  PluginButton:SetActive(false);
end)