-- { Packages } --

local Packages = script.Parent.Parent.Packages;

---@module Packages.React
local React = require(Packages.React);
---@module Packages.ReactRoblox
local ReactRoblox = require(Packages.ReactRoblox);
---@module Packages.ReactSpring
local ReactSpring = require(Packages.ReactSpring);

-- { Container Component } --

return function(Props)
  return React.createElement("Frame", {
    LayoutOrder = Props.LayoutOrder or 1,
    Name = "TabBar",
		Size = UDim2.fromScale(1, .1),
		BackgroundColor3 = Color3.fromRGB(50, 50, 50),
    BorderSizePixel = 0
  }, {
    React.createElement("UIListLayout", {
      SortOrder = Enum.SortOrder.LayoutOrder,
      FillDirection = Enum.FillDirection.Horizontal,
      HorizontalAlignment = Enum.HorizontalAlignment.Center,
      HorizontalFlex = Enum.UIFlexAlignment.Fill,
      VerticalAlignment = Enum.VerticalAlignment.Top,
      VerticalFlex = Enum.UIFlexAlignment.Fill
    }),
    Props.children
  });
end