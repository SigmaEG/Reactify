-- { Packages } --

local Packages = script.Parent.Parent.Packages;

---@module Packages.React
local React = require(Packages.React);
---@module Packages.ReactRoblox
local ReactRoblox = require(Packages.ReactRoblox);
---@module Packages.ReactSpring
local ReactSpring = require(Packages.ReactSpring);

-- { Container Component } --

local SettingsComponent = {};
SettingsComponent.react = React;
SettingsComponent.reactRoblox = ReactRoblox;

local function Component(Props)
  return React.createElement("Frame", {
    Name = "Reactify",
		Size = UDim2.fromScale(1, 1),
		BackgroundColor3 = Color3.fromRGB(50, 50, 50),
    BorderSizePixel = 0
  }, {
    React.createElement("UIListLayout", {
      SortOrder = Enum.SortOrder.LayoutOrder,
      FillDirection = Enum.FillDirection.Horizontal,
      HorizontalAlignment = Enum.HorizontalAlignment.Center,
      HorizontalFlex = Enum.UIFlexAlignment.Fill,
      VerticalAlignment = Enum.VerticalAlignment.Top,
      VerticalFlex = Enum.UIFlexAlignment.Fill
    }),
  });
end

SettingsComponent.story = function(Props)
  if (Props.controls == nil) then
    return Component(Props);
  else
    return React.createElement(Component);
  end
end

return SettingsComponent;