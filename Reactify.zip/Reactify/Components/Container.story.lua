-- { Packages } --

local Packages = script.Parent.Parent.Packages;

---@module Packages.React
local React = require(Packages.React);
---@module Packages.ReactRoblox
local ReactRoblox = require(Packages.ReactRoblox);
---@module Packages.ReactSpring
local ReactSpring = require(Packages.ReactSpring);

-- { Components } --

local TabBarComponent = require(script.Parent["TabBar"]);
local TabBarItemComponent = require(script.Parent["TabBarItem"]);
local ReactifyComponent = require(script.Parent["Reactify.story"]);
local SettingsComponent = require(script.Parent["Settings.story"]);

-- { Container Component } --

local ContainerComponent = {};
ContainerComponent.react = React;
ContainerComponent.reactRoblox = ReactRoblox;

local function Component(Props)
  local Selected, SetSelected = React.useState("Reactify");

  return React.createElement("Frame", {
    Name = "Main",
		Size = UDim2.fromScale(1, 1),
		BackgroundColor3 = Color3.fromRGB(50, 50, 50),
    BorderSizePixel = 0
  }, {
    React.createElement("UIListLayout", {
      SortOrder = Enum.SortOrder.LayoutOrder,
      FillDirection = Enum.FillDirection.Vertical,
      HorizontalFlex = Enum.UIFlexAlignment.Fill,
      VerticalFlex = Enum.UIFlexAlignment.Fill,
    }),
    React.createElement(TabBarComponent, {}, {
      React.createElement(TabBarItemComponent, {
        LayoutOrder = 1,
        ItemName = "Reactify",
        Selected = if (Selected == "Reactify") then true else false,
        SetSelected = SetSelected
      }),
      React.createElement(TabBarItemComponent, {
        LayoutOrder = 2,
        ItemName = "Settings",
        Selected = if (Selected == "Settings") then true else false,
        SetSelected = SetSelected
      })
    }),
    React.createElement("Frame", {
      LayoutOrder = 2,
      Name = "Content",
      Size = UDim2.fromScale(1, 1),
      BackgroundColor3 = Color3.fromRGB(50, 50, 50),
      BorderColor3 = Color3.fromRGB(35, 35, 35),
      BorderSizePixel = 2
    }, {
      React.createElement(if (Selected == "Reactify") then ReactifyComponent.story else SettingsComponent.story, {GetProperties = Props.GetProperties});
    })
  });
end

ContainerComponent.story = function(Props)
  if (Props.controls == nil) then
    return Component(Props);
  else
    return React.createElement(Component);
  end
end

return ContainerComponent;