--!strict

-- { Services } --

local SelectionService = game:GetService("Selection");
local ReplicatedStorage = game:GetService("ReplicatedStorage");

-- { Packages } --

local Packages = script.Parent.Parent.Packages;

---@module Packages.React
local React = require(Packages.React);
---@module Packages.ReactRoblox
local ReactRoblox = require(Packages.ReactRoblox);
---@module Packages.ReactSpring
local ReactSpring = require(Packages.ReactSpring);
local Highlighter = require(Packages.Highlighter);
local Properties = require(Packages.Properties);

-- { Container Component } --

local SnippetStructure =
[[
return React.createElement("%s", {
%s}, {}),
]];

local ReactifyComponent = {};
ReactifyComponent.react = React;
ReactifyComponent.reactRoblox = ReactRoblox;

local function Component(Props)
  if (not Props.GetProperties) then
    Props.GetProperties = Properties.new("FullAPIDump");
  end

  Highlighter.matchStudioSettings();

  local SaveToModuleText, SetSaveToModuleText = React.useBinding("Save to ModuleScript");
  local GameSelection, SetGameSelection = React.useBinding(nil);

  local function GenerateSnippet(Instance: Instance?, CurrentString: string?, Depth: number?): string
    if (not Instance) then
      return "return \"No Object Selected\";";
    end

    if (not CurrentString) then
      CurrentString = SnippetStructure;
    end

    if (not Depth) then
      Depth = 1;
    end

    local InstanceProperties: {[string]: any} = Props.GetProperties:GetPropertiesFilterDefault(Instance, true);
    local PropertiesSnippet: string = "";

    InstanceProperties["Name"] = nil;
    InstanceProperties["Parent"] = nil;

    for PropertyName, PropertyValue in pairs(InstanceProperties) do
      PropertiesSnippet ..= string.format("\t%s = %s,\n", PropertyName, tostring(PropertyValue));
    end

    CurrentString = string.format(SnippetStructure, Instance.ClassName, PropertiesSnippet, "");

    return CurrentString;
  end

  local SnippetText, SetSnippetText = React.useBinding(GenerateSnippet(nil));

  React.useEffect(function()
    local SelectedInstances = SelectionService:Get();

    if (#SelectedInstances == 0) then
      SetGameSelection(nil);
    else
      SetGameSelection(SelectedInstances[1]);
    end
  
    local Connection = SelectionService.SelectionChanged:Connect(function()
      local SelectedInstances = SelectionService:Get();

      if (#SelectedInstances == 0) then
        SetGameSelection(nil);

        return;
      end

      SetGameSelection(SelectedInstances[1]);
    end)
    
    return function()
      SetGameSelection(nil);

      Connection:Disconnect();
    end
  end)

  local ScrollingFrameRef = React.createRef();

  return React.createElement("Frame", {
    Name = "Reactify",
		Size = UDim2.fromScale(1, 1),
		BackgroundColor3 = Color3.fromRGB(50, 50, 50),
    BorderSizePixel = 0
  }, {
    React.createElement("UIListLayout", {
      SortOrder = Enum.SortOrder.LayoutOrder,
      FillDirection = Enum.FillDirection.Vertical,
      HorizontalAlignment = Enum.HorizontalAlignment.Center,
      HorizontalFlex = Enum.UIFlexAlignment.Fill,
      VerticalAlignment = Enum.VerticalAlignment.Top,
      Padding = UDim.new(.025, 0)
    }),
    React.createElement("UIPadding", {
      PaddingBottom = UDim.new(.025, 0),
      PaddingLeft = UDim.new(.025, 0),
      PaddingRight = UDim.new(.025, 0),
      PaddingTop = UDim.new(.025, 0)
    }),
    React.createElement("Frame", {
      LayoutOrder = 1,
      Name = "GeneratorFrame",
      Size = UDim2.fromScale(1, .15),
      BackgroundColor3 = Color3.fromRGB(60, 60, 60)
    }, {
      React.createElement("UIListLayout", {
        SortOrder = Enum.SortOrder.LayoutOrder,
        FillDirection = Enum.FillDirection.Vertical,
        HorizontalAlignment = Enum.HorizontalAlignment.Center,
        HorizontalFlex = Enum.UIFlexAlignment.Fill,
        VerticalAlignment = Enum.VerticalAlignment.Top,
        Padding = UDim.new(0, 15)
      }),
      React.createElement("UIPadding", {
        PaddingBottom = UDim.new(.1, 0),
        PaddingLeft = UDim.new(.025, 0),
        PaddingRight = UDim.new(.025, 0),
        PaddingTop = UDim.new(.1, 0)
      }),
      React.createElement("UICorner", {
        CornerRadius = UDim.new(0, 12)
      }),
      React.createElement("UIStroke", {
        Thickness = 2,
        Color = Color3.fromRGB(35, 35, 35)
      }),
      React.createElement("TextLabel", {
        Name = "Title",
        TextXAlignment = Enum.TextXAlignment.Left,
        LayoutOrder = 2,
        Font = Enum.Font.Roboto,
        BackgroundTransparency = 1,
        Size = UDim2.fromScale(1, .3),
        TextColor3 = Color3.fromRGB(255, 255, 255),
        TextScaled = true,
        Text = "Generator"
      }),
      React.createElement("Frame", {
        Name = "GeneratorNameDisplay",
        LayoutOrder = 3,
        BackgroundColor3 = Color3.fromRGB(45, 45, 45),
        Size = UDim2.fromScale(1, .5)
      }, {
        React.createElement("UIListLayout", {
          SortOrder = Enum.SortOrder.LayoutOrder,
          FillDirection = Enum.FillDirection.Horizontal,
          HorizontalAlignment = Enum.HorizontalAlignment.Center,
          HorizontalFlex = Enum.UIFlexAlignment.Fill,
          VerticalAlignment = Enum.VerticalAlignment.Center,
          Padding = UDim.new(0, 15)
        }),
        React.createElement("UIPadding", {
          PaddingBottom = UDim.new(.2, 0),
          PaddingLeft = UDim.new(.025, 0),
          PaddingRight = UDim.new(.025, 0),
          PaddingTop = UDim.new(.2, 0)
        }),
        React.createElement("UICorner", {
          CornerRadius = UDim.new(0, 12)
        }),
        React.createElement("UIStroke", {
          Thickness = 2,
          Color = Color3.fromRGB(35, 35, 35)
        }),
        React.createElement("ImageLabel", {
          LayoutOrder = 1,
          Name = "GeneratorTypeIcon",
          BackgroundTransparency = 1,
          Size = UDim2.fromScale(1, 1),
          Image = "rbxassetid://113625051647217",
        }, {
          React.createElement("UIAspectRatioConstraint")
        }),
        React.createElement("TextLabel", {
          Name = "GeneratorTypeName",
          TextXAlignment = Enum.TextXAlignment.Left,
          LayoutOrder = 2,
          Font = Enum.Font.Roboto,
          BackgroundTransparency = 1,
          Size = UDim2.fromScale(1, .9),
          TextColor3 = Color3.fromRGB(255, 255, 255),
          TextScaled = true,
          Text = "React (only one supported)"
        })
      })
    }),
    React.createElement("Frame", {
      LayoutOrder = 2,
      Name = "SelectionFrame",
      Size = UDim2.fromScale(1, .075),
      BackgroundColor3 = Color3.fromRGB(60, 60, 60)
    }, {
      React.createElement("UIListLayout", {
        SortOrder = Enum.SortOrder.LayoutOrder,
        FillDirection = Enum.FillDirection.Horizontal,
        HorizontalAlignment = Enum.HorizontalAlignment.Center,
        HorizontalFlex = Enum.UIFlexAlignment.Fill,
        VerticalAlignment = Enum.VerticalAlignment.Center,
        Padding = UDim.new(0, 15)
      }),
      React.createElement("UIPadding", {
        PaddingBottom = UDim.new(.2, 0),
        PaddingLeft = UDim.new(.025, 0),
        PaddingRight = UDim.new(.025, 0),
        PaddingTop = UDim.new(.2, 0)
      }),
      React.createElement("UICorner", {
        CornerRadius = UDim.new(0, 12)
      }),
      React.createElement("UIStroke", {
        Thickness = 2,
        Color = Color3.fromRGB(35, 35, 35)
      }),
      React.createElement("ImageLabel", {
        LayoutOrder = 1,
        Name = "SelectionImage",
        BackgroundTransparency = 1,
        Size = UDim2.fromScale(1, 1),
        Image = "rbxassetid://113625051647217",
      }, {
        React.createElement("UIAspectRatioConstraint")
      }),
      React.createElement("TextLabel", {
        Name = "SelectionClassName",
        TextXAlignment = Enum.TextXAlignment.Left,
        LayoutOrder = 2,
        Font = Enum.Font.Roboto,
        BackgroundTransparency = 1,
        Size = UDim2.fromScale(1, .9),
        TextColor3 = Color3.fromRGB(255, 255, 255),
        TextScaled = true,
        Text = GameSelection:map(function(Instance: Instance)
          if (not Instance) then
            return "No Object Selected";
          end

          return Instance.ClassName;
        end)
      })
    }),
    React.createElement("TextButton", {
      LayoutOrder = 3,
      TextXAlignment = Enum.TextXAlignment.Center,
      TextYAlignment = Enum.TextYAlignment.Center,
      Font = Enum.Font.Roboto,
      TextColor3 = Color3.fromRGB(255, 255, 255),
      TextScaled = true,
      Name = "GenerateSnippet",
      Text = "Generate Snippet",
      Size = UDim2.fromScale(1, .075),
      BackgroundColor3 = Color3.fromRGB(240 - 50, 219 - 50, 79 - 50),
      [React.Event.Activated] = function()
        local Snippet: string = GenerateSnippet(GameSelection:getValue());

        SetSnippetText(Snippet);

        ScrollingFrameRef.current.CanvasPosition = Vector2.new(0, 0);
      end
    }, {
      React.createElement("UIPadding", {
        PaddingBottom = UDim.new(.2, 0),
        PaddingLeft = UDim.new(.025, 0),
        PaddingRight = UDim.new(.025, 0),
        PaddingTop = UDim.new(.2, 0)
      }),
      React.createElement("UICorner", {
        CornerRadius = UDim.new(0, 12)
      }),
      React.createElement("UIStroke", {
        Thickness = 2,
        ApplyStrokeMode = Enum.ApplyStrokeMode.Border,
        Color = Color3.fromRGB(240 - 60, 219 - 60, 79 - 60)
      }),
    }),
    React.createElement("Frame", {
      LayoutOrder = 4,
      Name = "CodeSnippetContainer",
      Size = UDim2.fromScale(1, .525),
      BackgroundColor3 = Color3.fromRGB(60, 60, 60),
    }, {
      React.createElement("UIStroke", {
        Thickness = 2,
        ApplyStrokeMode = Enum.ApplyStrokeMode.Border,
        Color = Color3.fromRGB(35, 35, 35)
      }),
      React.createElement("UIPadding", {
        PaddingBottom = UDim.new(.025, 0),
        PaddingLeft = UDim.new(.025, 0),
        PaddingRight = UDim.new(.025, 0),
        PaddingTop = UDim.new(.025, 0)
      }),
      React.createElement("UICorner", {
        CornerRadius = UDim.new(0, 12)
      }),
      React.createElement("ScrollingFrame", {
        ref = ScrollingFrameRef,
        LayoutOrder = 4,
        Name = "CodeSnippetScroll",
        AutomaticCanvasSize = Enum.AutomaticSize.XY,
        CanvasSize = UDim2.fromScale(0, 0),
        Size = UDim2.fromScale(1, 1),
        BackgroundTransparency = 1,
        BorderSizePixel = 0
      }, {
        React.createElement("TextBox", {
          TextXAlignment = Enum.TextXAlignment.Left,
          TextYAlignment = Enum.TextYAlignment.Top,
          Font = Enum.Font.Roboto,
          TextColor3 = Color3.fromRGB(255, 255, 255),
          TextSize = 24,
          Name = "CodeSnippetText",
          MultiLine = true,
          TextEditable = false,
          RichText = true,
          TextWrapped = false,
          ClearTextOnFocus = false,
          Interactable = false,
          Text = SnippetText:map(function(Text: string)
            return table.concat(Highlighter.buildRichTextLines({src = Text}), "\n");
          end),
          AutomaticSize = Enum.AutomaticSize.XY,
          BackgroundTransparency = 1
        })
      }),
    }),
    React.createElement("Frame", {
      Name = "BottomButtonsContainer",
      LayoutOrder = 5,
      Size = UDim2.fromScale(1, .075),
      BackgroundTransparency = 1
    }, {
      React.createElement("TextButton", {
        TextXAlignment = Enum.TextXAlignment.Center,
        TextYAlignment = Enum.TextYAlignment.Center,
        Font = Enum.Font.Roboto,
        TextColor3 = Color3.fromRGB(255, 255, 255),
        TextScaled = true,
        Name = "SaveToModule",
        Text = SaveToModuleText,
        Position = UDim2.fromScale(1, .5),
        AnchorPoint = Vector2.new(1, .5),
        Size = UDim2.fromScale(.4, 1),
        BackgroundColor3 = Color3.fromRGB(50, 50, 50),
        [React.Event.Activated] = function()
          SetSaveToModuleText("Exported to ReplicatedStorage as 'ReactifyExport'");

          task.delay(1, SetSaveToModuleText, "Save to ModuleScript");

          local ModuleScript = ReplicatedStorage:FindFirstChild("ReactifyExport");

          if (not ModuleScript) then
            ModuleScript = Instance.new("ModuleScript");
            ModuleScript.Name = "ReactifyExport";
            ModuleScript.Parent = ReplicatedStorage;
          end

          ModuleScript.Source = SnippetText:getValue();
        end
      }, {
        React.createElement("UIPadding", {
          PaddingBottom = UDim.new(.2, 0),
          PaddingLeft = UDim.new(.025, 0),
          PaddingRight = UDim.new(.025, 0),
          PaddingTop = UDim.new(.2, 0)
        }),
        React.createElement("UICorner", {
          CornerRadius = UDim.new(0, 12)
        }),
        React.createElement("UIStroke", {
          Thickness = 2,
          ApplyStrokeMode = Enum.ApplyStrokeMode.Border,
          Color = Color3.fromRGB(35, 35, 35)
        }),
      }),
    }),
  });
end

ReactifyComponent.story = function(Props)
  if (Props.controls == nil) then
    return Component(Props);
  else
    return React.createElement(Component);
  end
end

return ReactifyComponent;