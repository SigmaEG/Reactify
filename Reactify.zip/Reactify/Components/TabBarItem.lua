-- { Packages } --

local Packages = script.Parent.Parent.Packages;

---@module Packages.React
local React = require(Packages.React);
---@module Packages.ReactRoblox
local ReactRoblox = require(Packages.ReactRoblox);
---@module Packages.ReactSpring
local ReactSpring = require(Packages.ReactSpring);

-- { Container Component } --

return function(Props)
  return React.createElement("Frame", {
    LayoutOrder = Props.LayoutOrder or 1,
    Name = Props.ItemName or "NoTitle",
    Size = UDim2.fromScale(1, .1),
    BackgroundColor3 = Color3.fromRGB(50, 50, 50),
    BorderColor3 = Color3.fromRGB(35, 35, 35),
    BorderSizePixel = 2
  }, {
    React.createElement("UIListLayout", {
      SortOrder = Enum.SortOrder.LayoutOrder,
      FillDirection = Enum.FillDirection.Vertical,
      HorizontalAlignment = Enum.HorizontalAlignment.Center,
      HorizontalFlex = Enum.UIFlexAlignment.Fill,
      VerticalAlignment = Enum.VerticalAlignment.Center,
      VerticalFlex = Enum.UIFlexAlignment.Fill
    }),
    React.createElement("Frame", {
      Name = "Separator",
      Size = UDim2.fromScale(1, .05),
      BackgroundColor3 = Color3.fromRGB(0, 150, 255),
      Visible = if (Props.Selected) then true else false
    }),
    React.createElement("ImageButton", {
      Name = "TitleContainer",
      Size = UDim2.fromScale(1, 1),
      ImageTransparency = 1,
      Image = "",
      BackgroundTransparency = 1,
      [React.Event.Activated] = function(Instance)
        Props.SetSelected(Props.ItemName);
      end
    }, {
      React.createElement("UIPadding", {
        PaddingBottom = UDim.new(.25, 0),
        PaddingLeft = UDim.new(.25, 0),
        PaddingRight = UDim.new(.25, 0),
        PaddingTop = UDim.new(.25, 0)
      }),
      React.createElement("UIListLayout", {
        SortOrder = Enum.SortOrder.LayoutOrder,
        FillDirection = Enum.FillDirection.Horizontal,
        HorizontalAlignment = Enum.HorizontalAlignment.Center,
        HorizontalFlex = Enum.UIFlexAlignment.Fill,
        VerticalAlignment = Enum.VerticalAlignment.Center,
        VerticalFlex = Enum.UIFlexAlignment.Fill
      }),
      React.createElement("ImageLabel", {
        Name = "ItemImage",
        LayoutOrder = 1,
        BackgroundTransparency = 1,
        Image = "rbxassetid://113625051647217",
      }, {
        React.createElement("UIAspectRatioConstraint")
      }),
      React.createElement("TextLabel", {
        Name = "ItemName",
        LayoutOrder = 2,
        Font = Enum.Font.Roboto,
        BackgroundTransparency = 1,
        TextColor3 = Color3.fromRGB(255, 255, 255),
        TextScaled = true,
        Text = Props.ItemName or "No Title"
      })
    })
  });
end
