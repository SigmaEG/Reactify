-- { Written by SigmaHelios } --

-- { Services } --

local HttpService = game:GetService("HttpService");

-- { Properties } --

local Properties = {
  FullAPIDumpContent = "https://raw.githubusercontent.com/MaximumADHD/Roblox-Client-Tracker/refs/heads/roblox/Full-API-Dump.json";
  APIDumpContent = "https://raw.githubusercontent.com/MaximumADHD/Roblox-Client-Tracker/refs/heads/roblox/API-Dump.json"
};
Properties.__index = Properties;

function Properties.new(Type: "FullAPIDump" | "APIDump")
  local self = {};
  self.APIDump = if (Type == "FullAPIDump") then Properties.GetFullAPIDump() else Properties.GetAPIDump();

  if (not self.APIDump) then
    return nil;
  end

  local function RecurseProperties(
    ReadProperties: {[string]: boolean},
    PropertiesToReturn: {[string]: any},
    OriginalInstance: Instance,
    ClassName: string,
    CheckDefault: boolean,
    PropertyValueAsString: boolean
  )
    for _, InstanceClass in ipairs(self.APIDump.Classes) do
      if (InstanceClass.Name == ClassName) then
        for _, Property in ipairs(InstanceClass.Members) do
          if (
            ReadProperties[string.lower(Property.Name)] or
            Property.MemberType ~= "Property" or
            (
              Property.Tags and (
                table.find(Property.Tags, "ReadOnly") or
                table.find(Property.Tags, "Hidden") or
                table.find(Property.Tags, "NotScriptable")
              )
            )
          ) then
            continue;
          end

          pcall(function()
            local PropertyValue: any = OriginalInstance[Property.Name];

            if (CheckDefault) then
              local CheckInstance: Instance = Instance.new(ClassName);

              if (CheckInstance[Property.Name] == PropertyValue) then
                CheckInstance:Destroy();

                return;
              end

              CheckInstance:Destroy();
            end
            
            if (Property.ValueType.Category == "DataType") then
              if (PropertyValueAsString) then
                if (Property.ValueType.Name == "BrickColor") then
                  PropertyValue = string.format("%s.new(\"%s\")", Property.ValueType.Name, tostring(OriginalInstance[Property.Name]));
                elseif (Property.ValueType.Name == "UDim2") then
                  PropertyValue = string.format("%s.new(%s)", Property.ValueType.Name, tostring(OriginalInstance[Property.Name]):gsub("{", ""):gsub("}", ""));
                else
                  PropertyValue = string.format("%s.new(%s)", Property.ValueType.Name, tostring(OriginalInstance[Property.Name]));
                end
              end
            elseif (Property.ValueType.Category == "Class") then
              PropertyValue = string.format("%s", OriginalInstance[Property.Name]:GetFullName());
            elseif (Property.ValueType.Name == "string") then
              PropertyValue = string.format("\"%s\"", PropertyValue);
            end

            PropertiesToReturn[Property.Name] = PropertyValue;

            ReadProperties[string.lower(Property.Name)] = true;
          end)
        end
      
        if (InstanceClass.Superclass ~= "<<<ROOT>>>") then
          RecurseProperties(ReadProperties, PropertiesToReturn, OriginalInstance, InstanceClass.Superclass, CheckDefault, PropertyValueAsString);
        end

        break;
      end
    end
  end

    -- Gets all the Properties, and their values, that are different to the Default Object values from the Instance Class
  function self:GetPropertiesFilterDefault(Instance: Instance, PropertyValueAsString: boolean): {[string]: any}
    if (not self.APIDump) then
      return nil :: any;
    end

    local ReadProperties: {[string]: boolean} = {};
    local PropertiesToReturn: {[string]: any} = {};

    RecurseProperties(ReadProperties, PropertiesToReturn, Instance, Instance.ClassName, true, PropertyValueAsString);

    return PropertiesToReturn;
  end

  -- Gets all the Properties, and their values, from the Instance Class
  function self:GetPropertiesNoFilter(Instance: Instance, PropertyValueAsString: boolean): {[string]: any}
    if (not self.APIDump) then
      return nil :: any;
    end

    local ReadProperties: {[string]: boolean} = {};
    local PropertiesToReturn: {[string]: any} = {};

    RecurseProperties(ReadProperties, PropertiesToReturn, Instance, Instance.ClassName, false, PropertyValueAsString);

    return PropertiesToReturn;
  end

  function self:Destroy()
    if (self.Destroying) then
      return;
    end

    self.Destroying = true;

    setmetatable(self, nil);
    table.freeze(self);
  end

  return setmetatable(self, Properties);
end

-- Retrieves a full API dump of ROBLOX Classes, alongside default values/properties
function Properties.GetFullAPIDump(): {[string]: any}
  local Success, Data = pcall(function()
    local Response: any = HttpService:GetAsync(Properties.FullAPIDumpContent);
    local JSONDecoded: {[string]: any} | any = HttpService:JSONDecode(Response);

    return JSONDecoded;
  end)

  if (Success) then
    return Data;
  end

  error(Data);

  return nil :: any;
end

-- Retrieves an API dump of ROBLOX Classes
function Properties.GetAPIDump(): {[string]: any}
  local Success, Data = pcall(function()
    local Response: any = HttpService:GetAsync(Properties.APIDumpContent);
    local JSONDecoded: {[string]: any} | any = HttpService:JSONDecode(Response);

    return JSONDecoded;
  end)

  if (Success) then
    return Data;
  end

  error(Data);

  return nil :: any;
end

return Properties;