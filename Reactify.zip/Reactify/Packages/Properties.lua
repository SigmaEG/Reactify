return require(script.Parent._Index["sigmaeg_properties@1.0.1"]["properties"])
