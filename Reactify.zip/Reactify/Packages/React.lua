return require(script.Parent._Index["jsdotlua_react@17.2.1"]["react"])
