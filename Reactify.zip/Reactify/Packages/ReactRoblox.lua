return require(script.Parent._Index["jsdotlua_react-roblox@17.2.1"]["react-roblox"])
