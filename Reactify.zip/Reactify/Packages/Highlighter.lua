return require(script.Parent._Index["boatbomber_highlighter@0.9.0"]["highlighter"])
