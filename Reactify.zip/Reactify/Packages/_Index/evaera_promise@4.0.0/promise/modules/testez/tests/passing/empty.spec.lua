-- luacheck: globals describe it
return function()
	describe("should pass", function()
		it("passing", function()
			-- An empty test should pass by default
		end)
	end)
end
