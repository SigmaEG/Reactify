local createEnum = import("../createEnum")

return createEnum("TextXAlignment", {
	Left = 0,
	Right = 1,
	Center = 2,
})