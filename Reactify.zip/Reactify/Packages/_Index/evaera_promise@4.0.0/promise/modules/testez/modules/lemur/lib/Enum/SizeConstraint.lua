local createEnum = import("../createEnum")

return createEnum("SizeConstraint", {
	RelativeXY = 0,
	RelativeXX = 1,
	RelativeYY = 2,
})