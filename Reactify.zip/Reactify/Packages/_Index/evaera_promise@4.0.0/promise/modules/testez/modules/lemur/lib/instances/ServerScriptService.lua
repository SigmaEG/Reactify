local BaseInstance = import("./BaseInstance")
local ServerScriptService = BaseInstance:extend("ServerScriptService")

return ServerScriptService