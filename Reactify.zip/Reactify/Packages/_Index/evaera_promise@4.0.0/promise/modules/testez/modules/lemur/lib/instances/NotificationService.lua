local BaseInstance = import("./BaseInstance")

return BaseInstance:extend("NotificationService", {
	creatable = true,
})