local createEnum = import("../createEnum")

return createEnum("SortOrder", {
	Name = 0,
	Custom = 1,
	LayoutOrder = 2,
})