local BaseInstance = import("./BaseInstance")
local AnalyticsService = BaseInstance:extend("AnalyticsService")

return AnalyticsService