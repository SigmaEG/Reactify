local createEnum = import("../createEnum")

return createEnum("TextTruncate", {
	None = 0,
	AtEnd = 1,
})