local BaseInstance = import("./BaseInstance")

return BaseInstance:extend("Model", {
	creatable = true,
})