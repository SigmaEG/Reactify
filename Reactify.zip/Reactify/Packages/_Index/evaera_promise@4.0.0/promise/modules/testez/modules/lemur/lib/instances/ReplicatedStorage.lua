local BaseInstance = import("./BaseInstance")

return BaseInstance:extend("ReplicatedStorage")