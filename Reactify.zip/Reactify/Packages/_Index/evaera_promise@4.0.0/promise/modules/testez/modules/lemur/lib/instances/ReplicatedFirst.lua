local BaseInstance = import("./BaseInstance")
local ReplicatedFirst = BaseInstance:extend("ReplicatedFirst")

return ReplicatedFirst