local createEnum = import("../createEnum")

return createEnum("ScrollingDirection", {
	X = 1,
	Y = 2,
	XY = 4,
})