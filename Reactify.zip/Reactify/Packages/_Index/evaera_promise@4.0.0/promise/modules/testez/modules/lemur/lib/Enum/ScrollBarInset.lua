local createEnum = import("../createEnum")

return createEnum("ScrollBarInset", {
	None = 0,
	ScrollBar = 1,
	Always = 2,
})