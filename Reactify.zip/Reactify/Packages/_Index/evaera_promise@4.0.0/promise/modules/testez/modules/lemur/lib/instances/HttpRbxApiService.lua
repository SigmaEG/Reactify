local BaseInstance = import("./BaseInstance")
local HttpRbxApiService = BaseInstance:extend("HttpRbxApiService")

return HttpRbxApiService