local createEnum = import("../createEnum")

return createEnum("EasingDirection", {
	In = 0,
	Out = 1,
	InOut = 2,
})