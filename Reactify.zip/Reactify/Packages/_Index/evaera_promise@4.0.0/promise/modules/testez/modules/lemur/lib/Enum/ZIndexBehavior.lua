local createEnum = import("../createEnum")

return createEnum("ZIndexBehavior", {
	Global = 0,
	Sibling = 1,
})