local BaseInstance = import("./BaseInstance")
local StarterPlayerScripts = BaseInstance:extend("StarterPlayerScripts")

return StarterPlayerScripts