local BaseInstance = import("./BaseInstance")

return BaseInstance:extend("Folder", {
	creatable = true,
})