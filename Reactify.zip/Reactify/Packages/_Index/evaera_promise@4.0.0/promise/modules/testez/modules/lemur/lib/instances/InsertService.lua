local BaseInstance = import("./BaseInstance")
local InsertService = BaseInstance:extend("InsertService")

return InsertService