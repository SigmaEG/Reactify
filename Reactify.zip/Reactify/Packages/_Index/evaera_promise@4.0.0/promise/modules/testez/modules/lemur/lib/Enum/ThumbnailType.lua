local createEnum = import("../createEnum")

return createEnum("ThumbnailType", {
	HeadShot = 0,
	AvatarBust = 1,
	AvatarThumbnail = 2,
})