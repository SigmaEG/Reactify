local BaseInstance = import("./BaseInstance")
local Stats = BaseInstance:extend("Stats")

return Stats