local BaseInstance = import("./BaseInstance")
local CorePackages = BaseInstance:extend("CorePackages")

return CorePackages