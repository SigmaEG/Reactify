local createEnum = import("../createEnum")

return createEnum("TextYAlignment", {
	Top = 0,
	Center = 1,
	Bottom = 2,
})