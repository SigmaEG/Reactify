local BaseInstance = import("./BaseInstance")
local ServerStorage = BaseInstance:extend("ServerStorage")

return ServerStorage