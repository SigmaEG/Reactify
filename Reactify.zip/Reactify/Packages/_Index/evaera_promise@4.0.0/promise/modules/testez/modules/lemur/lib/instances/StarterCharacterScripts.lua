local StarterPlayerScripts = import("./StarterPlayerScripts")
local StarterCharacterScripts = StarterPlayerScripts:extend("StarterCharacterScripts")

return StarterCharacterScripts