local createEnum = import("../createEnum")

return createEnum("CreatorType", {
	User = 0,
	Group = 1,
})