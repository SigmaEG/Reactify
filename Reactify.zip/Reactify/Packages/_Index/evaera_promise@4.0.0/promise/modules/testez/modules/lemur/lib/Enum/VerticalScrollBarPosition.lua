local createEnum = import("../createEnum")

return createEnum("VerticalScrollBarPosition", {
	Left = 1,
	Right = 0,
})