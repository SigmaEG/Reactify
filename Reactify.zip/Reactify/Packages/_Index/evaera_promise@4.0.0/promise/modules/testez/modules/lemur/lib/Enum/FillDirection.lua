local createEnum = import("../createEnum")

return createEnum("FillDirection", {
	Horizontal = 0,
	Vertical = 1,
})