local GuiObject = import("./GuiObject")

return GuiObject:extend("Frame", {
	creatable = true,
})