require(script.Parent.TestEZ).TestBootstrap:run({
	game.ServerScriptService.Lib
})