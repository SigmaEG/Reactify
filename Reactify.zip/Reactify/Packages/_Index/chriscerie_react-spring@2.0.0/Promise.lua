return require(script.Parent.Parent["evaera_promise@4.0.0"]["promise"])
