return require(script.Parent.Parent["jsdotlua_react@17.2.1"]["react"])
