local util = {
	merge = require(script.merge),
	map = require(script.map),
}

return util
