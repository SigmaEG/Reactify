local React = require(script.Parent.React)

return not React.reconcile
