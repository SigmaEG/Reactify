return require(script.Parent.Parent["roblox_testez@0.4.1"]["testez"])
