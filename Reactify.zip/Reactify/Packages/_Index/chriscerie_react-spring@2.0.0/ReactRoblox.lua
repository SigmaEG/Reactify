return require(script.Parent.Parent["jsdotlua_react-roblox@17.2.1"]["react-roblox"])
