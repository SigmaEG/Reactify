local makeConsoleImpl = require(script:WaitForChild('makeConsoleImpl'))

return makeConsoleImpl()
