return require(script.Parent.Parent["jsdotlua_collections@1.2.7"]["collections"])
