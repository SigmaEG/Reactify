return require(script.Parent.Parent["jsdotlua_number@1.2.7"]["number"])
