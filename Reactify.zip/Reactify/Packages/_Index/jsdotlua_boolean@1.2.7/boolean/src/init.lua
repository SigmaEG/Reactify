return {
	toJSBoolean = require(script:WaitForChild('toJSBoolean')),
}
