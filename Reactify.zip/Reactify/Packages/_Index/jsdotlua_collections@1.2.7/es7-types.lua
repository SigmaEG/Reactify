return require(script.Parent.Parent["jsdotlua_es7-types@1.2.7"]["es7-types"])
