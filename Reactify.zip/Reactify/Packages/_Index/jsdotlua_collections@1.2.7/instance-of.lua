return require(script.Parent.Parent["jsdotlua_instance-of@1.2.7"]["instance-of"])
