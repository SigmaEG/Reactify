return require(script.Parent.Parent["jsdotlua_console@1.2.7"]["console"])
