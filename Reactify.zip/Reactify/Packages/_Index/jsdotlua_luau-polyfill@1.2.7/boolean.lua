return require(script.Parent.Parent["jsdotlua_boolean@1.2.7"]["boolean"])
