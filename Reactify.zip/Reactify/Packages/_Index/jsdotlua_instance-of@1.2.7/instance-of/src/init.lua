local instanceof = require(script:WaitForChild('instanceof'))

return instanceof
